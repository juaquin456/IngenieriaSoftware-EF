Pregunta 3
- Cambiarian alguno metodos, como el de pagar. Ahora este tendra que tener un contador extra que se reseteara diariamente y se sumara el valor del pago con un limite.
- Probar si se puede pagar con falla mas de 200 soles
- El riesgo es moderado, porque se esta interviniendo un método crucial para el sistema, pero el cambio no es tan grande.